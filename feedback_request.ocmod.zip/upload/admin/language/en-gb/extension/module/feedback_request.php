<?php
// Heading
$_['heading_title']    = 'Feedback Request module';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified module!';
$_['text_edit']        = 'Edit Module';
$_['text_waiting']        = 'Waiting';
$_['text_done']        = 'Done';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify category module!';