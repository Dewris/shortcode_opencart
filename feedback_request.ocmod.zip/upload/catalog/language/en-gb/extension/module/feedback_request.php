<?php
// Heading
$_['heading_title']    = 'Feedback Request';
$_['entry_name']    = 'Name';
$_['entry_phone']    = 'Phone';
$_['entry_email']    = 'Email';
$_['entry_submit']    = 'Submit';

$_['error_name']     = 'Name must be between 3 and 32 characters!';
$_['error_phone']     = 'Phone number does not appear to be valid!';
$_['error_email']    = 'E-Mail Address does not appear to be valid!';

